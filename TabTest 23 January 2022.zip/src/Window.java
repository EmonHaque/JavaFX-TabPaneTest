import javafx.application.Platform;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Separator;
import javafx.scene.control.TabPane;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Window extends TabPane {
    Stage stage;
    ActionButton add, maxRestore;
    StackPane headerArea;
    HBox topButtons;
    double topButtonsWidth, headerAreaHeight, currentX, currentY;
    boolean isLoaded;

    public Window(Stage stage) {
        this.stage = stage;
        stage.initStyle(StageStyle.TRANSPARENT);
        add = new ActionButton(Icons.Add, "Add Tab");
        maxRestore = new ActionButton(Icons.Maximize, "Maximize");
        var minimize = new ActionButton(Icons.Minimize, "Minimize");
        var close = new ActionButton(Icons.Close, "Close");
        var separator = new Separator();
        separator.setOrientation(Orientation.VERTICAL);
        topButtons = new HBox(add, separator, minimize, maxRestore, close);

        setTabClosingPolicy(TabPane.TabClosingPolicy.ALL_TABS);
        add.setAction(this::addTab);
        getTabs().addAll(new Page());
        getChildren().add(topButtons);
        stage.setScene(new Scene(this, 640, 480));
        minimize.setAction(this::minimize);
        maxRestore.setAction(this::maxRestore);
        close.setAction(Platform::exit);
    }
    void setCurrentXY(MouseEvent e) {
        currentX = e.getX();
        currentY = e.getY();
    }
    void move(MouseEvent e) {
        stage.setX(e.getScreenX() - currentX);
        stage.setY(e.getScreenY() - currentY);
    }
    private void maxRestore() {
        if (stage.isMaximized()) {
            stage.setMaximized(false);
            maxRestore.setIcon(Icons.Maximize);
            maxRestore.setTip("Maximize");
        } else {
            stage.setMaximized(true);
            maxRestore.setIcon(Icons.Restore);
            maxRestore.setTip("Restore");
        }
    }
    private void minimize() {
        stage.setIconified(true);
    }
    public void show() {
        stage.show();
    }
    private void addTab() {
        var tab = new Page();
        getTabs().add(tab);
        getSelectionModel().select(tab);
    }
    @Override
    protected void layoutChildren() {
        if (!isLoaded) {
            headerArea = (StackPane) lookup(".tab-header-area");
            headerArea.setBackground(new Background(new BackgroundFill(Color.GRAY, null,null)));
            var headerBackground = (StackPane) lookup(".tab-header-background");
            headerBackground.setBackground(null);
            topButtonsWidth = topButtons.prefWidth(-1);
            headerAreaHeight = headerArea.prefHeight(-1);
            headerArea.setOnMousePressed(this::setCurrentXY);
            headerArea.setOnMouseDragged(this::move);
            isLoaded = true;
        }
        var headerAreaWidth = getWidth() - topButtonsWidth - 5;
        for (var c : getChildren()) {
            if (c == headerArea) {
                layoutInArea(headerArea, 0, 0, headerAreaWidth, headerAreaHeight, getBaselineOffset(), HPos.LEFT, VPos.TOP);
            } else if (c == topButtons) {
                layoutInArea(topButtons, headerAreaWidth, 7, topButtonsWidth, topButtons.getHeight(), getBaselineOffset(), HPos.LEFT, VPos.CENTER);
            } else {
                super.layoutChildren();
            }
        }
    }
}
