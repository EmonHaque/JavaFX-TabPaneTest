import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class App extends Application {
    int count = 0;
    @Override
    public void start(Stage stage) throws Exception {
        var window = new Window(stage);
        window.show();

//        var add = new Button("add");
//        var tabs = new TabPane();
//        var border = new BorderPane();
//        border.setTop(add);
//        border.setCenter(tabs);
//        stage.setScene(new Scene(border, 640,480));
//        stage.show();
//        add.setOnAction(e ->{
//            var tab = new Tab("Tab No. " + ++count);
//            tabs.getTabs().add(tab);
//            tabs.getSelectionModel().select(tab);
//        });
    }

    public static void main(String[] args) {
        launch(args);
    }
}
