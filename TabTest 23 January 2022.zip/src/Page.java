import javafx.concurrent.Task;
import javafx.concurrent.Worker;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Tab;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.*;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebHistory;
import javafx.scene.web.WebView;

public class Page extends Tab {
    WebEngine engine;
    WebHistory history;
    TextField urlField;
    ActionButton back, forward, reload, favorite, print;
    double zoomLevel = 1;

    public Page() {
        var border = new BorderPane();
        back = new ActionButton(Icons.Back, "Back");
        forward = new ActionButton(Icons.Forward, "Forward");
        reload = new ActionButton(Icons.Refresh, "Reload");
        urlField = new TextField();
        favorite = new ActionButton(Icons.Favorite, "Favorite");
        print = new ActionButton(Icons.Print, "Print");
        var topBox = new HBox(back, forward, reload, urlField, favorite, print);
        topBox.setAlignment(Pos.CENTER);
        topBox.setSpacing(1.5);
        HBox.setHgrow(urlField, Priority.ALWAYS);
        HBox.setMargin(urlField, new Insets(0,0,0,2));
        border.setTop(topBox);
        BorderPane.setMargin(topBox, new Insets(0,7,0,5));

        var web = new WebView();
        engine = web.getEngine();
        history = engine.getHistory();
        border.setCenter(web);
        setContent(border);
        urlField.setOnKeyReleased(this::onKeyReleased);
        setText("New Tab");

        engine.getLoadWorker().stateProperty().addListener((observable, oldValue, newValue) -> {
            if(newValue == Worker.State.SUCCEEDED) updateInfo();
        });
        web.addEventFilter(ScrollEvent.SCROLL, e ->{
            if(!e.isControlDown())  return;
            e.consume();
            if(e.getDeltaY() > 0) zoomLevel += 0.1;
            else zoomLevel -= 0.1;
            web.setZoom(zoomLevel);
        });
        back.setOnAction(this::back);
        forward.setOnAction(this::forward);
        reload.setOnAction(this::reload);
        print.setOnAction(this::print);
        setOnSelectionChanged(this::onSelectionChanged);
    }
    private void onSelectionChanged(Event event) {
        if(isSelected()) {
            setStyle("-fx-background-color:lightblue");
            new Task<Void>(){
                @Override
                protected Void call() { return null; }
                @Override
                protected void succeeded() { urlField.requestFocus(); }
            }.run();
        }
        else setStyle(null);
    }
    private void print(ActionEvent e) {}
    private void forward(ActionEvent event) { history.go(1); }
    private void back(ActionEvent event) { history.go(-1); }
    private void reload(ActionEvent e) { engine.reload(); }
    private void updateInfo(){
        var current = history.getEntries().get(history.getCurrentIndex());
        urlField.setText(current.getUrl());
        setText(current.getTitle());
    }
    private void onKeyReleased(KeyEvent e) {
        if(e.getCode() == KeyCode.ENTER && e.isControlDown()){
            var url = "http://" +  urlField.getText() + ".com";
            engine.load(url);
        }
        else if(e.getCode() == KeyCode.ENTER){
            var url = "http://" + urlField.getText();
            engine.load("http://" + urlField.getText());
        }
    }
}
