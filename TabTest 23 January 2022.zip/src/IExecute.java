public interface IExecute {
    void execute();
}
